export function cmAm(cm) {
    return cm/100;
}