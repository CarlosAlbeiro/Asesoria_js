import {menuLongitud} from './submenues.js';


export function mainMenu(params) {
    let seleccion = prompt("Ingrese 1 para convertir unidades de longitud");
    if (seleccion == "1"){
        menuLongitud();
    }
}

mainMenu();