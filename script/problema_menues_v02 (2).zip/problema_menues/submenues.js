import { cmMetrosServicio } from "./servicios.js";


export function menuLongitud(item = -1) {
    if (item == -1) {
        let seleccion = prompt("Ingrese 1 para convertir cm a m");
        if (seleccion == "1") {
            cmMetrosServicio();
        }
    } else {
        if (item == 1) {
            cmMetrosServicio();
        }
    }
}