import { cmAm } from "./longitudes.js";
import { menuLongitud } from "./submenues.js";
import { mainMenu } from "./main.js";


export function cmMetrosServicio() {
    let cm = parseFloat(prompt("Ingrese cm a convertir a metros"));
    let resultado = cmAm(cm);
    let mensajeResultado = String(cm) + " cm en metros son " + String(resultado) + " metros" + " \n Ingrese 0 para volver al menú pricipal \n Ingrese 1 para volver al pasar cm a metros";
    let atras = prompt(mensajeResultado);
    if (atras == "0") {
        mainMenu();
    }
    if (atras == "1") {
        menuLongitud(1);
    }
}