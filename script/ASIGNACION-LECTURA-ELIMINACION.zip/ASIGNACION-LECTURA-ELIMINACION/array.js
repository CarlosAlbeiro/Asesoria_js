//operaciones sobre arreglos
let arreglo = ["Juan", "Maria", "Pedro", "Pablo"];
//LECTURA
console.log(arreglo[1]);
console.log(arreglo[10]);
//ESCRITURA O ASIGNACIÓN
arreglo[0] = "Carlos";
console.log(arreglo);
//ELIMINACIÓN
arreglo.splice(1, 1);
console.log(arreglo);

