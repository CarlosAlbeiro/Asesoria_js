//MOSTRAR TODOS LOS ELEMENTOS DEL ARREGLO
let arreglo = ["Juan", "Maria", "Pedro", "Pablo"];
//sin usar arreglos:
arreglo[0]
arreglo[1]
arreglo[2]
arreglo[3]
//length devuelve la logitud del arreglo
//console.log("Longitud: ", arreglo.length);//muestra 4
let i = 0;
while (i < arreglo.length) {
    console.log(arreglo[i]);
    i++;
}


